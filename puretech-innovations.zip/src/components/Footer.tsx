import React, { useState, useEffect } from 'react';
import { ArrowUp, ArrowUpRight, Heart } from 'lucide-react';
import { COMPANY_FACTS } from '../data/content';

export const Footer: React.FC = () => {
  const [times, setTimes] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    const updateTimes = () => {
      const newTimes: { [key: string]: string } = {};
      COMPANY_FACTS.deliveryHubs.forEach((hub) => {
        try {
          const formatter = new Intl.DateTimeFormat('en-US', {
            timeZone: hub.timeZone,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true
          });
          newTimes[hub.city] = formatter.format(new Date());
        } catch {
          newTimes[hub.city] = '--:--:--';
        }
      });
      setTimes(newTimes);
    };

    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    return () => clearInterval(interval);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050608] text-slate-400 pt-20 pb-12 border-t border-white/[0.08] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Giant Fantasy.co style typographic callout */}
        <div className="pb-16 border-b border-white/[0.08]">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
            <h2 className="text-4xl sm:text-6xl lg:text-8xl font-display font-black text-white tracking-tighter leading-none">
              PURETECH <br />
              <span className="text-slate-500">INNOVATIONS</span>
            </h2>

            <button
              onClick={scrollToTop}
              id="back-to-top-btn"
              className="w-14 h-14 rounded-full border border-white/15 hover:border-white/40 bg-white/[0.03] hover:bg-white/[0.08] flex items-center justify-center text-white transition-colors cursor-pointer self-start lg:self-end"
              aria-label="Back to top"
            >
              <ArrowUp className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Studio Nodes & Live Clocks */}
        <div className="py-12 border-b border-white/[0.08] grid grid-cols-1 sm:grid-cols-3 gap-6">
          {COMPANY_FACTS.deliveryHubs.map((hub, idx) => (
            <div key={idx} className="space-y-1">
              <div className="text-[11px] font-mono-tech text-cyan-400 uppercase tracking-wider">
                {hub.city}
              </div>
              <div className="text-2xl font-mono-tech font-bold text-white tracking-tight">
                {times[hub.city] || 'LOADING...'}
              </div>
              <div className="text-xs text-slate-400">
                {hub.label}
              </div>
            </div>
          ))}
        </div>

        {/* Links Grid */}
        <div className="py-12 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-widest text-white">
              DISCIPLINES
            </div>
            <ul className="space-y-2 text-xs">
              <li><a href="#capabilities" className="hover:text-white transition-colors">Mobile App Development</a></li>
              <li><a href="#capabilities" className="hover:text-white transition-colors">Custom Website Development</a></li>
              <li><a href="#capabilities" className="hover:text-white transition-colors">Software Engineering & Branding</a></li>
              <li><a href="#capabilities" className="hover:text-white transition-colors">Web & Desktop Software</a></li>
              <li><a href="#capabilities" className="hover:text-white transition-colors">Digital Marketing & Growth</a></li>
              <li><a href="#capabilities" className="hover:text-white transition-colors">UI/UX Design & Prototyping</a></li>
              <li><a href="#capabilities" className="hover:text-white transition-colors">Quality Assurance & Testing</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-widest text-white">
              LABS & WORK
            </div>
            <ul className="space-y-2 text-xs">
              <li><a href="#process" className="hover:text-white transition-colors">5-Step Development Journey</a></li>
              <li><a href="#about" className="hover:text-white transition-colors">Foundational Pillars</a></li>
              <li><a href="#about" className="hover:text-white transition-colors">Development Practices Manifesto</a></li>
              <li><a href="#work" className="hover:text-white transition-colors">Featured Client Systems</a></li>
              <li><a href="#what-if" className="hover:text-white transition-colors">What If? Innovation Lab</a></li>
              <li><a href="#estimator" className="hover:text-white transition-colors">Project Scope Estimator</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-widest text-white">
              HEADQUARTERS
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              14800 Hopewell Rd<br />
              Alpharetta, GA 30004<br />
              United States
            </p>
            <div className="pt-1 text-xs font-mono-tech text-cyan-400 space-y-0.5">
              <div>{COMPANY_FACTS.phone}</div>
              <div>{COMPANY_FACTS.secondaryPhone}</div>
              <div className="text-slate-400 lowercase">{COMPANY_FACTS.email}</div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase tracking-widest text-white">
              SECURITY & LEGAL
            </div>
            <ul className="space-y-2 text-xs">
              <li className="text-slate-400">100% Bilateral NDA Guaranteed</li>
              <li className="text-slate-400">SOC2 & HIPAA Compliant Architecture</li>
              <li className="text-slate-400">Zero-Defect QA Protocols</li>
              <li><a href="#contact" className="text-cyan-400 hover:underline">Request Mutual NDA</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div className="pt-8 border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400 font-mono-tech">
          <div>
            © {new Date().getFullYear()} PureTech Innovations LLC. All rights reserved.
          </div>
          <div>
            Redesigned with the Fantasy.co architectural aesthetic · Alpharetta, GA
          </div>
        </div>
      </div>
    </footer>
  );
};
