import React, { useState, useEffect, useRef } from 'react';
import { X, Play, Pause, Volume2, VolumeX, Maximize2, SkipForward } from 'lucide-react';

interface ReelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReelModal: React.FC<ReelModalProps> = ({ isOpen, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(14);
  const [activeChapter, setActiveChapter] = useState(0);

  const chapters = [
    { title: 'Hyperion In-Cabin Autonomous OS', category: 'AUTOMOTIVE OS', videoUrl: '/videos/veloce-capital.mp4' },
    { title: 'Synapse Multimodal Reasoning Canvas', category: 'AI OPERATING SYSTEM', videoUrl: '/videos/omnihealth-ai.mp4' },
    { title: 'Aura Lossless Spatial Audio & App', category: 'CONSUMER FLAGSHIP', videoUrl: '/videos/solaris-os.mp4' },
    { title: 'AeroLogix Autonomous Intermodal Fleet OS', category: 'ENTERPRISE & CLOUD', videoUrl: '/videos/aerologix-global.mp4' }
  ];

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    window.addEventListener('keydown', handleKeyDown);
    document.body.style.overflow = 'hidden';

    const timer = setInterval(() => {
      if (isPlaying) {
        setCurrentTime((prev) => (prev >= 140 ? 0 : prev + 1));
      }
    }, 1000);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
      clearInterval(timer);
    };
  }, [isOpen, isPlaying, onClose]);

  if (!isOpen) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div
      id="fantasy-reel-modal"
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex flex-col justify-between p-4 sm:p-8 animate-in fade-in duration-300"
    >
      {/* Top Header */}
      <div className="flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-xs font-mono-tech tracking-widest text-white uppercase">
            PURETECH SHOWREEL // 4K CINEMATIC MASTER
          </span>
        </div>

        <button
          onClick={onClose}
          className="w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          aria-label="Close Showreel"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Main Video Viewport */}
      <div className="relative w-full max-w-6xl mx-auto aspect-video rounded-2xl overflow-hidden border border-white/20 bg-[#06070a] shadow-2xl flex items-center justify-center group my-auto">
        <video
          key={chapters[activeChapter].videoUrl}
          autoPlay
          loop
          muted={isMuted}
          playsInline
          className="w-full h-full object-cover"
          poster="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=2000&q=80"
        >
          <source
            src={chapters[activeChapter].videoUrl}
            type="video/mp4"
          />
        </video>

        {/* Scanlines and film grain effect */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 pointer-events-none" />

        {/* Chapter Title overlay */}
        <div className="absolute top-6 left-6 pointer-events-none">
          <span className="text-[10px] font-mono-tech text-cyan-400 uppercase tracking-widest block">
            NOW PLAYING CHAPTER {activeChapter + 1}
          </span>
          <span className="text-xl sm:text-2xl font-display font-bold text-white">
            {chapters[activeChapter].title}
          </span>
        </div>

        {/* Large Play/Pause center overlay on hover */}
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="w-20 h-20 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center text-white transition-transform duration-200 hover:scale-110 cursor-pointer"
        >
          {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-1" />}
        </button>
      </div>

      {/* Bottom Controls Bar */}
      <div className="w-full max-w-6xl mx-auto space-y-3 z-10">
        {/* Progress Scrubber */}
        <div className="w-full h-1.5 bg-white/20 rounded-full overflow-hidden relative cursor-pointer group">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 via-sky-400 to-cyan-400 relative"
            style={{ width: `${(currentTime / 140) * 100}%` }}
          >
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono-tech text-slate-300">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="hover:text-white flex items-center gap-1.5 cursor-pointer uppercase"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? 'PAUSE' : 'PLAY'}</span>
            </button>

            <button
              onClick={() => setIsMuted(!isMuted)}
              className="hover:text-white flex items-center gap-1.5 cursor-pointer uppercase"
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
              <span>{isMuted ? 'UNMUTE' : 'MUTE AUDIO'}</span>
            </button>

            <span className="text-slate-500">|</span>

            <span>{formatTime(currentTime)} / 02:20</span>
          </div>

          {/* Chapters Jump buttons */}
          <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-1">
            {chapters.map((ch, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setActiveChapter(idx);
                  setCurrentTime(idx * 35);
                }}
                className={`px-3 py-1 rounded-full text-[11px] whitespace-nowrap transition-colors cursor-pointer ${
                  activeChapter === idx
                    ? 'bg-white text-slate-950 font-bold'
                    : 'bg-white/10 hover:bg-white/20 text-slate-300'
                }`}
              >
                0{idx + 1} {ch.title.split(' ')[0]}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
