import React, { useState } from 'react';
import { Cpu, Smartphone, Globe, LayoutGrid, ShieldCheck, Terminal, CheckCircle2, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CAPABILITIES } from '../data/content';
import { Capability } from '../types';
import { fadeInUp, fadeInScale } from './MotionWrappers';

const ICON_MAP: Record<string, React.ReactNode> = {
  Cpu: <Cpu className="w-5 h-5 sm:w-6 sm:h-6 text-sky-400" />,
  Smartphone: <Smartphone className="w-5 h-5 sm:w-6 sm:h-6 text-indigo-400" />,
  Globe: <Globe className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-400" />,
  LayoutGrid: <LayoutGrid className="w-5 h-5 sm:w-6 sm:h-6 text-rose-400" />,
  ShieldCheck: <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-purple-400" />,
  Terminal: <Terminal className="w-5 h-5 sm:w-6 sm:h-6 text-cyan-400" />
};

interface CapabilitiesProps {
  onStartProjectWithCapability: (capabilityName: string) => void;
}

export const CapabilitiesSection: React.FC<CapabilitiesProps> = ({
  onStartProjectWithCapability
}) => {
  const [activeCapability, setActiveCapability] = useState<Capability>(CAPABILITIES[0]);

  return (
    <section id="capabilities" className="py-20 sm:py-32 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header - Staggered entrance */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.12 }
            }
          }}
          className="max-w-3xl mb-12 sm:mb-16"
        >
          <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 text-xs font-mono-tech uppercase tracking-[0.2em] text-cyan-400 mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            CORE DISCIPLINES & EXPERTISE
          </motion.div>
          <motion.h2 variants={fadeInUp} className="text-3xl sm:text-5xl lg:text-6xl font-display font-black text-white tracking-tight leading-tight mb-4">
            Full-spectrum software craftsmanship.
          </motion.h2>
          <motion.p variants={fadeInUp} className="text-base sm:text-lg text-slate-300 font-light leading-relaxed">
            From raw low-level embedded hardware hooks to human-centric mobile apps and distributed cloud microservices. Quality assurance and automated testing are baked into every sprint.
          </motion.p>
        </motion.div>

        {/* Interactive 2-Column Disciplines Browser */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: List of Disciplines (Staggered buttons) */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-60px' }}
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: { staggerChildren: 0.08 }
              }
            }}
            className="lg:col-span-5 space-y-2.5"
          >
            {CAPABILITIES.map((cap) => {
              const isActive = activeCapability.id === cap.id;
              return (
                <motion.button
                  key={cap.id}
                  variants={fadeInScale}
                  id={`capability-btn-${cap.id}`}
                  onClick={() => setActiveCapability(cap)}
                  className={`w-full text-left p-4 sm:p-5 rounded-2xl transition-all duration-200 cursor-pointer flex items-center justify-between border ${
                    isActive
                      ? 'bg-white/[0.1] border-white/25 shadow-xl'
                      : 'bg-white/[0.02] border-white/[0.05] hover:bg-white/[0.05] hover:border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <span className={`font-mono-tech text-xs sm:text-sm font-bold tracking-wider ${
                      isActive ? 'text-cyan-400' : 'text-slate-400'
                    }`}>
                      {cap.number}
                    </span>
                    <span className={`font-display text-base sm:text-lg font-bold tracking-tight ${
                      isActive ? 'text-white' : 'text-slate-300'
                    }`}>
                      {cap.title}
                    </span>
                  </div>

                  <div className="shrink-0 ml-2">
                    {ICON_MAP[cap.iconName]}
                  </div>
                </motion.button>
              );
            })}
          </motion.div>

          {/* Right Column: Detailed Capability Dashboard with smooth motion transitions */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-7 bg-[#0e1018]/95 border border-white/10 rounded-2xl sm:rounded-3xl p-6 sm:p-10 relative overflow-hidden shadow-2xl backdrop-blur-xl"
          >
            {/* Ambient looping video background inside detailed dashboard */}
            <div className="absolute inset-0 pointer-events-none -z-10 overflow-hidden">
              <video
                autoPlay
                loop
                muted
                playsInline
                preload="auto"
                className="w-full h-full object-cover opacity-20 filter contrast-125 brightness-75"
              >
                <source src="/videos/capabilities-bg.mp4" type="video/mp4" />
              </video>
              <div className="absolute inset-0 bg-gradient-to-b from-[#0e1018]/90 via-[#0e1018]/95 to-[#0e1018]" />
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={activeCapability.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                className="space-y-8"
              >
                {/* Top Banner */}
                <div className="flex items-start justify-between gap-4 border-b border-white/[0.08] pb-6">
                  <div>
                    <span className="text-xs font-mono-tech uppercase tracking-widest text-cyan-400 mb-1 block">
                      DISCIPLINE {activeCapability.number}
                    </span>
                    <h3 className="text-2xl sm:text-4xl font-display font-extrabold text-white tracking-tight">
                      {activeCapability.title}
                    </h3>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.05] border border-white/10 shrink-0">
                    {ICON_MAP[activeCapability.iconName]}
                  </div>
                </div>

                {/* Tagline & Description */}
                <div className="space-y-3">
                  <p className="text-lg font-medium text-slate-200">
                    {activeCapability.tagline}
                  </p>
                  <p className="text-sm sm:text-base text-slate-300 font-light leading-relaxed">
                    {activeCapability.description}
                  </p>
                </div>

                {/* Sub-Services Checklist */}
                <div className="space-y-3">
                  <span className="text-xs font-mono-tech uppercase tracking-widest text-slate-400 block">
                    SPECIALIZED SCOPES & ARCHITECTURES
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {activeCapability.subServices.map((service, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300 bg-white/[0.02] p-2.5 rounded-xl border border-white/[0.04]"
                      >
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                        <span>{service}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Technologies */}
                <div className="space-y-3">
                  <span className="text-xs font-mono-tech uppercase tracking-widest text-slate-400 block">
                    FRAMEWORKS, RUNTIMES & CLOUDS
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {activeCapability.technologies.map((t, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 rounded-lg bg-white/[0.06] border border-white/10 text-xs font-mono-tech text-slate-200"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Deliverables & Direct Inquiry CTA */}
                <div className="pt-6 border-t border-white/[0.08] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-[11px] font-mono-tech text-emerald-400 flex items-center gap-1.5 uppercase">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      Dedicated Senior Engineering Squads
                    </span>
                    <span className="text-xs text-slate-400 font-light block">
                      Zero junior handoffs · Direct architect Slack/Teams channel
                    </span>
                  </div>

                  <button
                    id={`inquire-cap-${activeCapability.id}`}
                    onClick={() => onStartProjectWithCapability(activeCapability.title)}
                    className="px-6 py-3 rounded-full bg-white hover:bg-slate-200 text-slate-950 font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md active:scale-95"
                  >
                    <span>Engage This Discipline</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
