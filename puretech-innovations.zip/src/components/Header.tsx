import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, Sun, Moon, Volume2, VolumeX, Play, Sparkles } from 'lucide-react';
import { COMPANY_FACTS } from '../data/content';
import { ambientAudio } from '../utils/audio';

interface HeaderProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onOpenEstimator: () => void;
  onOpenContact: () => void;
  onOpenReel: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  darkMode,
  setDarkMode,
  onOpenEstimator,
  onOpenContact,
  onOpenReel
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('work');
  const [audioActive, setAudioActive] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);

      const sections = ['work', 'capabilities', 'what-if', 'estimator', 'about', 'contact'];
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 240 && rect.bottom >= 240) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleSound = () => {
    const state = ambientAudio.toggle();
    setAudioActive(state);
  };

  const scrollToSection = (id: string) => {
    setMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'py-3.5 bg-[#08090d]/90 backdrop-blur-xl border-b border-white/[0.08] shadow-2xl'
            : 'py-5 sm:py-6 bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Brand Logo - Fantasy style minimalist wordmark with glowing dot */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group flex items-center gap-2.5 cursor-pointer"
              id="brand-logo"
            >
              <div className="flex items-center gap-1.5">
                <span className="font-display text-lg sm:text-xl font-extrabold tracking-tight text-white group-hover:text-cyan-400 transition-colors">
                  PURETECH
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
              </div>
              <span className="hidden sm:inline-block text-[10px] font-mono-tech uppercase tracking-widest text-slate-400 px-2 py-0.5 rounded bg-white/[0.04] border border-white/[0.06]">
                DIGITAL PRODUCT & AI AGENCY
              </span>
            </a>

            {/* Center Navigation Links (Exact Fantasy.co signature) */}
            <nav className="hidden lg:flex items-center gap-6 text-xs font-mono-tech uppercase tracking-wider text-slate-300">
              <button
                onClick={onOpenReel}
                className="hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer py-1 text-cyan-400"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>REEL</span>
              </button>

              {[
                { id: 'work', label: 'WORK' },
                { id: 'capabilities', label: 'SERVICES' },
                { id: 'process', label: 'PROCESS' },
                { id: 'about', label: 'PILLARS' },
                { id: 'what-if', label: 'WHAT IF?' },
                { id: 'estimator', label: 'ESTIMATOR' },
                { id: 'contact', label: 'CONTACT' }
              ].map((item) => (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => scrollToSection(item.id)}
                  className={`transition-colors cursor-pointer py-1 relative ${
                    activeSection === item.id
                      ? 'text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {item.label}
                  {activeSection === item.id && (
                    <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-cyan-400" />
                  )}
                </button>
              ))}
            </nav>

            {/* Right Side: Sound Toggle + Light/Dark + Fantasy Menu Button */}
            <div className="flex items-center gap-2.5 sm:gap-3">
              {/* Sound Toggle (Interactive Fantasy Audio) */}
              <button
                id="header-sound-btn"
                onClick={toggleSound}
                className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full border text-[11px] font-mono-tech uppercase transition-all cursor-pointer ${
                  audioActive
                    ? 'bg-cyan-500/15 border-cyan-400 text-cyan-300 shadow-sm'
                    : 'bg-white/[0.04] border-white/[0.08] text-slate-400 hover:text-white'
                }`}
                title="Toggle Ambient Audio Experience"
              >
                {audioActive ? (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                    <span>AUDIO ON</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="w-3.5 h-3.5" />
                    <span>SOUND</span>
                  </>
                )}
              </button>

              {/* Theme Toggle */}
              <button
                id="theme-toggle-btn"
                onClick={() => setDarkMode(!darkMode)}
                className="w-9 h-9 rounded-full bg-white/[0.05] border border-white/[0.08] flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/[0.1] transition-colors cursor-pointer"
                title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {darkMode ? <Sun className="w-3.5 h-3.5 text-amber-300" /> : <Moon className="w-3.5 h-3.5 text-indigo-300" />}
              </button>

              {/* Fantasy.co iconic MENU button */}
              <button
                id="fantasy-menu-btn"
                onClick={() => setMenuOpen(!menuOpen)}
                className="px-4 sm:px-5 py-2 rounded-full bg-white text-slate-950 font-display font-bold text-xs uppercase tracking-wider hover:bg-slate-200 transition-all duration-200 flex items-center gap-2 cursor-pointer shadow-lg shadow-white/10 active:scale-95"
              >
                {menuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
                <span>{menuOpen ? 'CLOSE' : 'MENU'}</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Fullscreen Cinematic Fantasy Menu Drawer (Desktop & Mobile) */}
      {menuOpen && (
        <div
          id="fantasy-fullscreen-menu"
          className="fixed inset-0 z-40 bg-[#06070a]/98 backdrop-blur-2xl flex flex-col justify-between pt-24 pb-8 px-6 sm:px-12 lg:px-20 overflow-y-auto animate-in fade-in duration-200"
        >
          {/* Top Bar inside Menu */}
          <div className="flex items-center justify-between pb-6 border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-mono-tech text-slate-300 uppercase tracking-widest">
                STUDIO STATUS: READY FOR Q3/Q4 ENGAGEMENTS
              </span>
            </div>

            <button
              onClick={toggleSound}
              className="text-xs font-mono-tech text-cyan-400 flex items-center gap-1.5 hover:underline cursor-pointer"
            >
              {audioActive ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              <span>{audioActive ? 'AMBIENT AUDIO ACTIVE' : 'ENABLE AMBIENT AUDIO'}</span>
            </button>
          </div>

          {/* Main Giant Menu Links - Fantasy Signature */}
          <div className="py-8 my-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 flex flex-col space-y-4 sm:space-y-6">
              {[
                { id: 'work', num: '01', title: 'SELECTED WORK', subtitle: 'AI, Mobile, Fintech, Logistics' },
                { id: 'reel', num: '02', title: '4K SHOWREEL', subtitle: 'Motion Design & Product Reels', isReel: true },
                { id: 'what-if', num: '03', title: 'WHAT IF? LAB', subtitle: 'Futuristic R&D Prototypes' },
                { id: 'capabilities', num: '04', title: 'CAPABILITIES', subtitle: '06 Engineering Disciplines' },
                { id: 'estimator', num: '05', title: 'SCOPE ESTIMATOR', subtitle: 'Interactive Sprint Blueprint' },
                { id: 'about', num: '06', title: 'ABOUT PURETECH', subtitle: 'Alpharetta, GA · Principles & QA' },
                { id: 'contact', num: '07', title: 'LET’S TALK', subtitle: 'Start a Project Under NDA' }
              ].map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    setMenuOpen(false);
                    if (item.isReel) {
                      onOpenReel();
                    } else {
                      scrollToSection(item.id);
                    }
                  }}
                  className="group flex items-baseline gap-4 sm:gap-8 cursor-pointer text-left py-1"
                >
                  <span className="text-xs sm:text-sm font-mono-tech text-cyan-400/80 group-hover:text-cyan-400 tracking-wider">
                    {item.num}
                  </span>
                  <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-6">
                    <span className="text-3xl sm:text-5xl lg:text-6xl font-display font-black tracking-tight text-white group-hover:text-cyan-400 group-hover:translate-x-2 transition-all duration-200">
                      {item.title}
                    </span>
                    <span className="text-xs font-mono-tech text-slate-400 group-hover:text-slate-300 transition-colors">
                      {item.subtitle}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Right Column: Office Hubs & Direct Inquiry */}
            <div className="lg:col-span-4 p-6 sm:p-8 rounded-3xl bg-white/[0.02] border border-white/10 space-y-6">
              <div className="space-y-1.5">
                <span className="text-xs font-mono-tech uppercase tracking-widest text-cyan-400 block">
                  HEADQUARTERS
                </span>
                <p className="text-sm text-slate-200 font-light">
                  {COMPANY_FACTS.headquarters}
                </p>
                <span className="text-xs font-mono-tech text-slate-400 block pt-1">
                  PHONE: {COMPANY_FACTS.phone}
                </span>
              </div>

              <div className="pt-4 border-t border-white/10 space-y-2">
                <span className="text-xs font-mono-tech uppercase tracking-widest text-slate-400 block">
                  DIRECT PARTNERSHIP
                </span>
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onOpenContact();
                  }}
                  className="w-full py-3.5 px-6 rounded-full bg-white hover:bg-slate-200 text-slate-950 font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <span>Initiate Inquiry Under NDA</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Bottom Footer inside Menu */}
          <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono-tech text-slate-400">
            <div>© {new Date().getFullYear()} PURETECH INNOVATIONS // FANTASY-CLASS DESIGN</div>
            <div className="flex items-center gap-4">
              <span>ALPHARETTA</span>
              <span>•</span>
              <span>SAN FRANCISCO</span>
              <span>•</span>
              <span>LONDON</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
