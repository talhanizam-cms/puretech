import React, { useState, useRef } from 'react';
import { Play, ArrowDown, Sparkles, Maximize2, Shield, Zap, Award, Layers } from 'lucide-react';
import { motion } from 'motion/react';
import { staggerContainer, fadeInUp, fadeInScale } from './MotionWrappers';
import { HeroWebGL } from './HeroWebGL';

interface HeroProps {
  onOpenEstimator: () => void;
  onOpenContact: () => void;
  onExploreWork: () => void;
  onOpenReel: () => void;
}

interface VideoChapter {
  id: string;
  label: string;
  category: string;
  title: string;
  videoUrl: string;
}

const SHOWCASE_CHAPTERS: VideoChapter[] = [
  {
    id: 'mobile-app',
    label: '01 Mobile App',
    category: 'MOBILE APP DEVELOPMENT',
    title: 'Intuitive High-Performance iOS & Android Solutions',
    videoUrl: '/videos/solaris-os.mp4'
  },
  {
    id: 'custom-web',
    label: '02 Custom Web',
    category: 'CUSTOM WEBSITE DEV',
    title: 'Modern Customer Portals & Scalable Web Solutions',
    videoUrl: '/videos/veloce-capital.mp4'
  },
  {
    id: 'software-eng',
    label: '03 Software Eng',
    category: 'SOFTWARE ENGINEERING',
    title: 'Reliable Architectures & Custom Software Built for Growth',
    videoUrl: '/videos/omnihealth-ai.mp4'
  },
  {
    id: 'master-reel',
    label: '04 PureTech Reel',
    category: 'DIGITAL INNOVATION',
    title: 'PureTech Innovations Digital Product Showcase',
    videoUrl: '/videos/hero-onesided-reel.mp4'
  }
];

export const Hero: React.FC<HeroProps> = ({
  onOpenEstimator,
  onOpenContact,
  onExploreWork,
  onOpenReel
}) => {
  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const activeChapter = SHOWCASE_CHAPTERS[activeChapterIndex];

  // 3D perspective tilt coordinates for the one-sided video object
  const videoObjectRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!videoObjectRef.current) return;
    const rect = videoObjectRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: -(y * 12), y: x * 12 });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  return (
    <section className="relative min-h-[96vh] sm:min-h-screen pt-28 sm:pt-36 pb-16 flex flex-col justify-between overflow-hidden">
      {/* Interactive Three.js WebGL kinetic element in background */}
      <HeroWebGL />

      {/* Subtle architectural grid texture */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none -z-10"
        style={{
          backgroundImage: `linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)`,
          backgroundSize: '48px 48px'
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10 my-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* ======================================================== */}
          {/* LEFT SIDE: Typography, Brand Statement & Calls to Action */}
          {/* ======================================================== */}
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="lg:col-span-7 flex flex-col justify-center"
          >
            {/* Top Eyebrow - Fantasy.co style positioning pill */}
            <motion.div
              variants={fadeInUp}
              className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-white/[0.05] border border-white/[0.12] backdrop-blur-md mb-6 sm:mb-8 w-fit"
            >
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span className="text-[10px] sm:text-xs font-mono-tech tracking-wider text-slate-200 uppercase font-medium">
                Digital Transformation · PureTech Innovations
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-[10px] sm:text-xs font-mono-tech text-cyan-400 font-semibold uppercase">
                Home 2.0
              </span>
            </motion.div>

            {/* Giant Display Headline - Fantasy.co Signature */}
            <motion.h1
              variants={fadeInUp}
              className="text-4xl sm:text-6xl lg:text-7xl font-display font-black tracking-[-0.04em] text-white leading-[1.02] mb-6"
            >
              Transform Ideas Into{' '}
              <span className="bg-gradient-to-r from-white via-cyan-100 to-slate-400 bg-clip-text text-transparent">
                Success.
              </span>
              <span className="block text-2xl sm:text-4xl lg:text-5xl text-slate-400 font-light mt-2 tracking-tight">
                Technology That Moves Your Business Forward.
              </span>
            </motion.h1>

            <motion.p
              variants={fadeInUp}
              className="text-base sm:text-lg lg:text-xl text-slate-300 font-light max-w-2xl leading-relaxed mb-8 sm:mb-10"
            >
              We help businesses turn ambitious ideas into powerful digital products through innovative technology, smart strategy, and seamless user experiences. Build smarter, scale faster with custom software designed around your business.
            </motion.p>

            {/* Action Row */}
            <motion.div
              variants={staggerContainer}
              className="flex flex-wrap items-center gap-3.5 sm:gap-4 mb-10"
            >
              <motion.button
                variants={fadeInScale}
                id="hero-watch-reel-btn"
                data-cursor="play"
                data-magnetic
                onClick={onOpenReel}
                className="px-7 py-4 rounded-full bg-white text-slate-950 font-display font-bold text-xs sm:text-sm uppercase tracking-wider hover:bg-slate-200 transition-all duration-200 flex items-center justify-center gap-2.5 shadow-2xl shadow-white/20 cursor-pointer active:scale-95"
              >
                <Play className="w-4 h-4 fill-current text-slate-950" />
                <span>Watch 4K Showreel</span>
              </motion.button>

              <motion.button
                variants={fadeInScale}
                id="hero-explore-work-btn"
                data-magnetic
                onClick={onExploreWork}
                className="px-6 py-4 rounded-full bg-white/[0.08] hover:bg-white/[0.14] text-white font-display font-semibold text-xs sm:text-sm uppercase tracking-wider transition-all duration-200 border border-white/[0.16] flex items-center justify-center gap-2 backdrop-blur-md cursor-pointer active:scale-95"
              >
                <span>Explore Services</span>
                <ArrowDown className="w-4 h-4 text-cyan-400" />
              </motion.button>

              <motion.button
                variants={fadeInScale}
                id="hero-estimator-btn"
                data-magnetic
                onClick={onOpenEstimator}
                className="px-6 py-4 rounded-full bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 font-display font-semibold text-xs sm:text-sm uppercase tracking-wider transition-all duration-200 border border-cyan-500/30 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Request a Quote</span>
              </motion.button>
            </motion.div>

            {/* Credibility Micro-Badges */}
            <motion.div
              variants={fadeInUp}
              className="flex flex-wrap items-center gap-y-2 gap-x-6 text-[11px] font-mono-tech text-slate-400"
            >
              <div className="flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                <span>100% IP OWNERSHIP & NDA</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                <span>QA BUILT INTO EVERY PRODUCT</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-cyan-400" />
                <span>WEB, MOBILE & DESKTOP</span>
              </div>
            </motion.div>
          </motion.div>

          {/* ========================================================================= */}
          {/* RIGHT SIDE: ONE-SIDED VIDEO OBJECT (Fantasy.co signature digital showcase) */}
          {/* ========================================================================= */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
            className="lg:col-span-5 relative"
          >
            {/* Ambient Backlight Glow behind the one-sided video object */}
            <div className="absolute -inset-2 bg-gradient-to-tr from-cyan-500/20 via-indigo-500/15 to-purple-500/20 rounded-[34px] blur-2xl opacity-75 pointer-events-none" />

            {/* The One-Sided Video Object Container with 3D Tilt */}
            <div
              ref={videoObjectRef}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              style={{
                transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
                transition: 'transform 0.15s ease-out'
              }}
              className="relative rounded-[28px] p-2 bg-gradient-to-b from-white/20 via-white/5 to-white/10 border border-white/20 shadow-2xl backdrop-blur-xl group cursor-pointer"
              onClick={onOpenReel}
            >
              {/* Inner Hardware/Device Screen Bezel */}
              <div className="relative rounded-[22px] overflow-hidden bg-[#06070b] aspect-[16/11] border border-black/80">
                {/* Looping Showreel Video inside the Object */}
                <video
                  key={activeChapter.videoUrl}
                  autoPlay
                  loop
                  muted
                  playsInline
                  preload="auto"
                  className="w-full h-full object-cover filter contrast-[1.08] brightness-[1.02]"
                >
                  <source src={activeChapter.videoUrl} type="video/mp4" />
                </video>

                {/* Subtle glass reflection gradient */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.03] to-white/[0.08] pointer-events-none" />

                {/* Top HUD Overlay inside the video object */}
                <div className="absolute top-3 inset-x-3 flex items-center justify-between pointer-events-none z-10">
                  <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-black/70 border border-white/15 backdrop-blur-md">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                    <span className="text-[10px] font-mono-tech tracking-wider text-white font-bold uppercase">
                      LIVE PROTOTYPE // {activeChapter.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/70 border border-white/15 backdrop-blur-md">
                    <span className="text-[10px] font-mono-tech text-cyan-300 font-semibold">
                      4K · 60 FPS
                    </span>
                  </div>
                </div>

                {/* Center Hover Action Pill */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/35 backdrop-blur-[2px]">
                  <div className="px-5 py-2.5 rounded-full bg-white text-slate-950 flex items-center gap-2 font-display font-bold text-xs uppercase tracking-wider shadow-2xl transform scale-95 group-hover:scale-100 transition-transform">
                    <Play className="w-3.5 h-3.5 fill-current text-slate-950" />
                    <span>Open Full 4K Theater</span>
                    <Maximize2 className="w-3 h-3 text-slate-600 ml-1" />
                  </div>
                </div>

                {/* Bottom Title Bar inside the Video Object */}
                <div className="absolute bottom-3 inset-x-3 z-10 pointer-events-none">
                  <div className="p-3 rounded-xl bg-black/75 border border-white/10 backdrop-blur-md flex items-center justify-between">
                    <div>
                      <div className="text-[9px] font-mono-tech text-cyan-400 uppercase tracking-widest">
                        {activeChapter.label}
                      </div>
                      <div className="text-xs sm:text-sm font-display font-bold text-white tracking-tight">
                        {activeChapter.title}
                      </div>
                    </div>
                    <div className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center text-white">
                      <Play className="w-3 h-3 fill-current" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Interactive Chapter Selector Pills right beneath the video object */}
              <div 
                className="mt-3 pt-2 border-t border-white/10 grid grid-cols-4 gap-1.5"
                onClick={(e) => e.stopPropagation()}
              >
                {SHOWCASE_CHAPTERS.map((ch, idx) => {
                  const isActive = activeChapterIndex === idx;
                  return (
                    <button
                      key={ch.id}
                      onClick={() => setActiveChapterIndex(idx)}
                      className={`px-2 py-1.5 rounded-lg text-[10px] font-mono-tech font-semibold uppercase tracking-wider transition-all duration-200 text-center cursor-pointer ${
                        isActive
                          ? 'bg-cyan-400 text-slate-950 shadow-md shadow-cyan-400/20 font-bold'
                          : 'bg-white/5 hover:bg-white/10 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {ch.label.split(' ')[1]}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Side Callout Annotation (Fantasy.co studio aesthetic) */}
            <div className="mt-3 flex items-center justify-between text-[11px] font-mono-tech text-slate-400 px-2">
              <span className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>INTERACTIVE DIGITAL ATELIER</span>
              </span>
              <span className="text-cyan-400 hover:underline cursor-pointer" onClick={onOpenReel}>
                EXPLORE ALL REELS →
              </span>
            </div>
          </motion.div>

        </div>

        {/* Live Metrics Grid & Telemetry Banner - Staggered entrance */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.1, delayChildren: 0.4 }
            }
          }}
          className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 pt-12 sm:pt-16 mt-12 sm:mt-16 border-t border-white/[0.08]"
        >
          <motion.div variants={fadeInUp} className="space-y-1">
            <div className="text-2xl sm:text-3xl font-display font-bold text-white tracking-tight">
              100%
            </div>
            <div className="text-[11px] font-mono-tech text-cyan-400 uppercase tracking-wider">
              MUTUAL NDA PROTECTED
            </div>
            <div className="text-xs text-slate-400">
              Bilateral confidentiality for all client IP
            </div>
          </motion.div>

          <motion.div variants={fadeInUp} className="space-y-1">
            <div className="text-2xl sm:text-3xl font-display font-bold text-white tracking-tight">
              &lt; 8ms
            </div>
            <div className="text-[11px] font-mono-tech text-cyan-400 uppercase tracking-wider">
              LOW-LATENCY RUNTIMES
            </div>
            <div className="text-xs text-slate-400">
              High-throughput edge &amp; AI engines
            </div>
          </motion.div>

          <motion.div variants={fadeInUp} className="space-y-1">
            <div className="text-2xl sm:text-3xl font-display font-bold text-white tracking-tight">
              0.01%
            </div>
            <div className="text-[11px] font-mono-tech text-cyan-400 uppercase tracking-wider">
              ZERO-DEFECT QA RIGOR
            </div>
            <div className="text-xs text-slate-400">
              Automated hardware &amp; software verification
            </div>
          </motion.div>

          <motion.div variants={fadeInUp} className="space-y-1">
            <div className="text-2xl sm:text-3xl font-display font-bold text-white tracking-tight">
              3 HUBS
            </div>
            <div className="text-[11px] font-mono-tech text-cyan-400 uppercase tracking-wider">
              GLOBAL DELIVERY HUBS
            </div>
            <div className="text-xs text-slate-400">
              Alpharetta HQ, San Francisco, London UK
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom Scroll Indicator - Fantasy.co signature */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9, duration: 0.8 }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10 pt-8 flex items-center justify-between text-xs font-mono-tech text-slate-400"
      >
        <button
          onClick={onExploreWork}
          className="hover:text-white flex items-center gap-2 cursor-pointer transition-colors"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" />
          <span>SCROLL TO EXPLORE WORK</span>
          <ArrowDown className="w-3.5 h-3.5" />
        </button>

        <div className="hidden sm:flex items-center gap-4">
          <span>ALPHARETTA, GA EST</span>
          <span>•</span>
          <span>AI-NATIVE PRODUCT ATELIER</span>
        </div>
      </motion.div>
    </section>
  );
};
