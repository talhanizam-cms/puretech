import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export const HeroWebGL: React.FC = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isSupported, setIsSupported] = useState(true);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Check WebGL availability
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        setIsSupported(false);
        return;
      }
    } catch {
      setIsSupported(false);
      return;
    }

    // 1. Scene setup
    const scene = new THREE.Scene();

    // 2. Camera setup
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(1.5, 0, 6.2);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    container.appendChild(renderer.domElement);

    // 4. Main Group for agency-grade 3D kinetic object
    const mainGroup = new THREE.Group();
    // Position slightly to the right to frame the typography harmoniously
    mainGroup.position.set(1.8, 0.2, 0);
    scene.add(mainGroup);

    // Create a circular glowing particle texture procedurally
    const createParticleTexture = () => {
      const canvas = document.createElement('canvas');
      canvas.width = 64;
      canvas.height = 64;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
        gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
        gradient.addColorStop(0.2, 'rgba(56, 189, 248, 0.9)');
        gradient.addColorStop(0.5, 'rgba(34, 211, 238, 0.3)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 64, 64);
      }
      return new THREE.CanvasTexture(canvas);
    };

    const particleTexture = createParticleTexture();

    // A. Outer Floating Constellation / Digital Node Cloud
    const particleCount = 280;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const scales = new Float32Array(particleCount);
    const basePositions: [number, number, number][] = [];

    for (let i = 0; i < particleCount; i++) {
      // Golden spiral distribution on sphere with jitter
      const phi = Math.acos(1 - 2 * (i + 0.5) / particleCount);
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;
      const radius = 2.2 + (Math.random() - 0.5) * 0.9;

      const x = radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.sin(phi) * Math.sin(theta);
      const z = radius * Math.cos(phi);

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      basePositions.push([x, y, z]);
      scales[i] = Math.random() * 0.6 + 0.4;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.14,
      map: particleTexture,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      color: 0x38bdf8
    });

    const particles = new THREE.Points(particleGeo, particleMat);
    mainGroup.add(particles);

    // B. Geometric Core: Icosahedron Wireframe Structure
    const icoGeo = new THREE.IcosahedronGeometry(1.65, 2);
    const wireframeMat = new THREE.MeshBasicMaterial({
      color: 0x0ea5e9,
      wireframe: true,
      transparent: true,
      opacity: 0.22,
      blending: THREE.AdditiveBlending
    });
    const icoMesh = new THREE.Mesh(icoGeo, wireframeMat);
    mainGroup.add(icoMesh);

    // C. Inner Quantum Core
    const innerGeo = new THREE.IcosahedronGeometry(0.85, 1);
    const innerMat = new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
      wireframe: true,
      transparent: true,
      opacity: 0.45,
      blending: THREE.AdditiveBlending
    });
    const innerMesh = new THREE.Mesh(innerGeo, innerMat);
    mainGroup.add(innerMesh);

    // D. Orbital Gyroscopic Rings
    const ringGeo1 = new THREE.TorusGeometry(2.35, 0.012, 16, 100);
    const ringMat1 = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending
    });
    const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
    ring1.rotation.x = Math.PI / 3;
    ring1.rotation.y = Math.PI / 6;
    mainGroup.add(ring1);

    const ringGeo2 = new THREE.TorusGeometry(2.65, 0.008, 16, 100);
    const ringMat2 = new THREE.MeshBasicMaterial({
      color: 0x818cf8,
      transparent: true,
      opacity: 0.28,
      blending: THREE.AdditiveBlending
    });
    const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
    ring2.rotation.x = -Math.PI / 4;
    ring2.rotation.z = Math.PI / 5;
    mainGroup.add(ring2);

    // 5. Interactive Mouse & Cursor Following Logic
    const mouse = {
      x: 0,
      y: 0,
      targetX: 0,
      targetY: 0
    };

    const handleMouseMove = (e: MouseEvent) => {
      // Normalize mouse coordinates to -1 to +1 across the window
      mouse.targetX = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.targetY = -(e.clientY / window.innerHeight) * 2 + 1;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    // 6. Responsive Resize Observer
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;

      // Adjust group position based on viewport size (center on mobile, right on desktop)
      if (w < 768) {
        mainGroup.position.set(0, -0.4, -0.5);
        mainGroup.scale.set(0.72, 0.72, 0.72);
      } else if (w < 1200) {
        mainGroup.position.set(1.1, 0.1, 0);
        mainGroup.scale.set(0.88, 0.88, 0.88);
      } else {
        mainGroup.position.set(1.8, 0.2, 0);
        mainGroup.scale.set(1, 1, 1);
      }

      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);
    handleResize();

    // 7. Animation Loop with Dynamic Cursor Parallax & Pulse
    let animId: number;
    let clock = new THREE.Clock();
    let isVisible = true;

    // Visibility intersection observer to pause rendering when scrolled past hero
    const intersectionObserver = new IntersectionObserver(([entry]) => {
      isVisible = entry.isIntersecting;
    }, { threshold: 0.05 });
    intersectionObserver.observe(container);

    const animate = () => {
      animId = requestAnimationFrame(animate);
      if (!isVisible) return;

      const elapsed = clock.getElapsedTime();

      // Smooth dampening interpolation towards cursor position (spring lag)
      mouse.x += (mouse.targetX - mouse.x) * 0.045;
      mouse.y += (mouse.targetY - mouse.y) * 0.045;

      // 3D Parallax Camera Response
      camera.position.x = 1.5 + mouse.x * 0.8;
      camera.position.y = mouse.y * 0.6;
      camera.lookAt(mainGroup.position.x * 0.6, mainGroup.position.y * 0.6, 0);

      // Kinetic Object Rotation + Cursor Angular Response
      mainGroup.rotation.y = elapsed * 0.12 + mouse.x * 0.65;
      mainGroup.rotation.x = Math.sin(elapsed * 0.15) * 0.1 - mouse.y * 0.45;
      mainGroup.rotation.z = Math.cos(elapsed * 0.1) * 0.05;

      // Independent internal orbital spins
      innerMesh.rotation.x -= 0.008;
      innerMesh.rotation.y += 0.015;

      icoMesh.rotation.y += 0.003;
      icoMesh.rotation.x += 0.002;

      ring1.rotation.z += 0.005;
      ring2.rotation.z -= 0.004;

      // Subtle breathing vertex deformation
      const posAttr = particleGeo.attributes.position;
      const posArray = posAttr.array as Float32Array;
      for (let i = 0; i < particleCount; i++) {
        const [bx, by, bz] = basePositions[i];
        const wave = Math.sin(elapsed * 1.8 + i * 0.12) * 0.08;
        posArray[i * 3] = bx * (1 + wave);
        posArray[i * 3 + 1] = by * (1 + wave);
        posArray[i * 3 + 2] = bz * (1 + wave);
      }
      posAttr.needsUpdate = true;

      renderer.render(scene, camera);
    };

    animate();

    // 8. Cleanup
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', handleMouseMove);
      resizeObserver.disconnect();
      intersectionObserver.disconnect();

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }

      particleGeo.dispose();
      particleMat.dispose();
      icoGeo.dispose();
      wireframeMat.dispose();
      innerGeo.dispose();
      innerMat.dispose();
      ringGeo1.dispose();
      ringMat1.dispose();
      ringGeo2.dispose();
      ringMat2.dispose();
      particleTexture.dispose();
      renderer.dispose();
    };
  }, []);

  if (!isSupported) return null;

  return (
    <div
      ref={containerRef}
      aria-hidden="true"
      className="absolute inset-0 w-full h-full pointer-events-none z-[1] overflow-hidden opacity-90 transition-opacity duration-700"
    />
  );
};
