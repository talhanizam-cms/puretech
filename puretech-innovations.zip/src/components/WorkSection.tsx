import React, { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { CASE_STUDIES } from '../data/content';
import { CaseStudy, ProjectCategory } from '../types';
import { fadeInUp, fadeInScale } from './MotionWrappers';

interface WorkSectionProps {
  onSelectCaseStudy: (study: CaseStudy) => void;
}

export const WorkSection: React.FC<WorkSectionProps> = ({ onSelectCaseStudy }) => {
  const [selectedCategory, setSelectedCategory] = useState<ProjectCategory>('all');
  const [hoveredProjectId, setHoveredProjectId] = useState<string | null>(null);

  const filteredProjects = selectedCategory === 'all'
    ? CASE_STUDIES
    : CASE_STUDIES.filter(p => p.category === selectedCategory);

  const categories: { id: ProjectCategory; label: string }[] = [
    { id: 'all', label: 'All Work (6)' },
    { id: 'ai', label: 'AI & Intelligence' },
    { id: 'mobile', label: 'Mobile Flagships' },
    { id: 'web', label: 'Web & Digital Platforms' },
    { id: 'enterprise', label: 'Enterprise & Systems' }
  ];

  return (
    <section id="work" className="py-24 sm:py-36 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-cyan-600/5 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute bottom-1/4 left-0 w-[500px] h-[500px] bg-indigo-600/5 rounded-full blur-[140px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header - Staggered entrance */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.12 }
            }
          }}
          className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6"
        >
          <div>
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 text-xs font-mono-tech uppercase tracking-[0.2em] text-cyan-400 mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
              SELECTED WORK & CLIENT IMPACT
            </motion.div>
            <motion.h2 variants={fadeInUp} className="text-3xl sm:text-5xl lg:text-7xl font-display font-black text-white tracking-tighter leading-tight">
              Intelligent products. <br />
              <span className="text-slate-400">Measurable impact.</span>
            </motion.h2>
          </div>

          <motion.p variants={fadeInUp} className="text-sm sm:text-base text-slate-300 max-w-md font-light leading-relaxed">
            Every case study represents an end-to-end partnership from discovery and technical design to deployment, automated QA, and high-concurrency scale.
          </motion.p>
        </motion.div>

        {/* Category Filters - Staggered pills */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          variants={{
            hidden: { opacity: 0, y: 15 },
            visible: {
              opacity: 1,
              y: 0,
              transition: { staggerChildren: 0.06 }
            }
          }}
          className="flex items-center gap-2.5 overflow-x-auto pb-4 mb-12 sm:mb-16 scrollbar-none"
        >
          {categories.map((cat) => (
            <motion.button
              key={cat.id}
              variants={fadeInScale}
              id={`filter-work-${cat.id}`}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 py-2.5 rounded-full text-xs font-mono-tech uppercase tracking-wider whitespace-nowrap transition-all duration-200 cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-white text-slate-950 font-bold shadow-lg shadow-white/10'
                  : 'bg-white/[0.04] text-slate-300 hover:text-white hover:bg-white/[0.08] border border-white/[0.06]'
              }`}
            >
              {cat.label}
            </motion.button>
          ))}
        </motion.div>

        {/* Projects Grid - Staggered animated cards with video backgrounds */}
        <motion.div
          layout
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.15, delayChildren: 0.05 }
            }
          }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-10"
        >
          {filteredProjects.map((project) => {
            return (
              <motion.div
                key={project.id}
                variants={fadeInScale}
                layout
                id={`project-card-${project.id}`}
                data-cursor="view"
                data-magnetic
                onClick={() => onSelectCaseStudy(project)}
                onMouseEnter={() => setHoveredProjectId(project.id)}
                onMouseLeave={() => setHoveredProjectId(null)}
                className="group relative rounded-3xl overflow-hidden border border-white/[0.1] bg-[#0c0e15]/90 backdrop-blur-md transition-all duration-300 hover:border-white/30 hover:shadow-2xl hover:shadow-cyan-500/10 cursor-pointer flex flex-col"
              >
                {/* Media Container with Looping Video & Image Fallback */}
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-black">
                  {/* HTML5 Video element looping in card background */}
                  {project.videoUrl && (
                    <video
                      autoPlay
                      loop
                      muted
                      playsInline
                      preload="auto"
                      poster={project.heroImage}
                      className="absolute inset-0 w-full h-full object-cover filter brightness-95 group-hover:brightness-110 transition-transform duration-700 group-hover:scale-105"
                    >
                      <source src={project.videoUrl} type="video/mp4" />
                    </video>
                  )}

                  {/* Fallback image if video is absent */}
                  {!project.videoUrl && (
                    <img
                      src={project.heroImage}
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter brightness-85 group-hover:brightness-95"
                      loading="lazy"
                    />
                  )}

                  {/* Dark vignette gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0c0e15] via-black/20 to-black/50" />

                  {/* Top badges */}
                  <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
                    <span className="px-3.5 py-1.5 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-mono-tech uppercase tracking-wider text-white">
                      {project.categoryLabel}
                    </span>
                    <span className="px-3.5 py-1.5 rounded-full bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-mono-tech text-cyan-400 font-bold">
                      {project.year}
                    </span>
                  </div>

                  {/* Highlight Metric Pill */}
                  <div className="absolute bottom-4 left-4 pointer-events-none">
                    <div className="px-4 py-2 rounded-2xl bg-black/80 backdrop-blur-md border border-white/15 flex items-center gap-2.5 shadow-xl">
                      <span className="text-base sm:text-lg font-display font-extrabold text-cyan-400">
                        {project.metrics[0].value}
                      </span>
                      <span className="text-[11px] font-mono-tech text-slate-300">
                        {project.metrics[0].label}
                      </span>
                    </div>
                  </div>

                  {/* Video Motion Active badge */}
                  <div className="absolute bottom-4 right-4 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="px-3 py-1 rounded-full bg-cyan-500/20 backdrop-blur-md border border-cyan-400/40 text-[10px] font-mono-tech uppercase text-cyan-300 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                      <span>MOTION REEL</span>
                    </div>
                  </div>
                </div>

                {/* Card Footer Content */}
                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                  <div className="space-y-2 mb-6">
                    <div className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider">
                      {project.client}
                    </div>
                    <h3 className="text-2xl sm:text-3xl font-display font-black text-white group-hover:text-cyan-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm sm:text-base text-slate-300 font-light line-clamp-2 leading-relaxed">
                      {project.tagline}
                    </p>
                  </div>

                  {/* Tech stack chips & Deep Dive CTA */}
                  <div className="pt-5 border-t border-white/[0.08] flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2 flex-wrap">
                      {project.techStack.slice(0, 3).map((t, idx) => (
                        <span key={idx} className="text-[11px] font-mono-tech text-slate-400 bg-white/[0.04] px-2.5 py-1 rounded-full border border-white/[0.06]">
                          {t}
                        </span>
                      ))}
                      {project.techStack.length > 3 && (
                        <span className="text-[10px] font-mono-tech text-slate-400">
                          +{project.techStack.length - 3}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 text-xs font-mono-tech uppercase tracking-wider text-slate-100 group-hover:text-cyan-400 transition-colors shrink-0">
                      <span>View Project</span>
                      <ArrowUpRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};
