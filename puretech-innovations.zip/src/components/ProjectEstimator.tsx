import React, { useState } from 'react';
import { Sparkles, Check, Clock, Users, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { fadeInUp, fadeInScale } from './MotionWrappers';

interface EstimatorProps {
  onSubmitEstimate: (summary: string) => void;
}

export const ProjectEstimator: React.FC<EstimatorProps> = ({ onSubmitEstimate }) => {
  const [platform, setPlatform] = useState<'mobile' | 'web' | 'ai' | 'enterprise'>('ai');
  const [scope, setScope] = useState<'mvp' | 'growth' | 'enterprise'>('growth');
  const [aiTier, setAiTier] = useState<'none' | 'rag' | 'edge-agents'>('edge-agents');
  const [qaLevel, setQaLevel] = useState<'standard' | 'rigorous'>('rigorous');
  const [velocity, setVelocity] = useState<'expedited' | 'standard'>('expedited');

  // Dynamic calculations
  let estimatedWeeks = 12;
  let squadSize = 4;
  let keyStack = ['React', 'Node.js', 'PostgreSQL'];

  if (platform === 'mobile') {
    estimatedWeeks = scope === 'mvp' ? 8 : scope === 'growth' ? 14 : 22;
    squadSize = scope === 'mvp' ? 3 : 5;
    keyStack = ['SwiftUI', 'Kotlin Compose', 'Flutter', 'Fastlane', 'Appium'];
  } else if (platform === 'web') {
    estimatedWeeks = scope === 'mvp' ? 6 : scope === 'growth' ? 12 : 20;
    squadSize = scope === 'mvp' ? 3 : 4;
    keyStack = ['React 19', 'Next.js', 'TypeScript', 'Node.js', 'AWS EKS'];
  } else if (platform === 'ai') {
    estimatedWeeks = scope === 'mvp' ? 10 : scope === 'growth' ? 16 : 24;
    squadSize = scope === 'mvp' ? 4 : 6;
    keyStack = ['PyTorch', 'Gemini API', 'Pinecone', 'Python', 'FastAPI', 'Docker'];
  } else if (platform === 'enterprise') {
    estimatedWeeks = scope === 'mvp' ? 14 : scope === 'growth' ? 22 : 32;
    squadSize = scope === 'mvp' ? 5 : 8;
    keyStack = ['Java Spring', 'React', 'Kafka', 'PostgreSQL', 'Kubernetes', 'Selenium'];
  }

  if (aiTier === 'edge-agents') estimatedWeeks += 2;
  if (qaLevel === 'rigorous') squadSize += 1;
  if (velocity === 'expedited') {
    estimatedWeeks = Math.max(6, Math.round(estimatedWeeks * 0.75));
    squadSize += 1;
  }

  const handleBookProposal = () => {
    const summary = `Platform: ${platform.toUpperCase()} | Scope: ${scope.toUpperCase()} | AI: ${aiTier.toUpperCase()} | QA: ${qaLevel.toUpperCase()} | Est. Duration: ${estimatedWeeks} Weeks | Pod: ${squadSize} Senior Engineers`;
    onSubmitEstimate(summary);
  };

  return (
    <section id="estimator" className="py-20 sm:py-32 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.12 }
            }
          }}
          className="max-w-3xl mb-12 sm:mb-16"
        >
          <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 text-xs font-mono-tech uppercase tracking-[0.2em] text-cyan-400 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            INTERACTIVE SCOPE & VELOCITY CALCULATOR
          </motion.div>
          <motion.h2 variants={fadeInUp} className="text-3xl sm:text-5xl lg:text-6xl font-display font-black text-white tracking-tight leading-tight mb-4">
            Configure your technical blueprint.
          </motion.h2>
          <motion.p variants={fadeInUp} className="text-base sm:text-lg text-slate-300 font-light leading-relaxed">
            Get instantaneous clarity on engineering sprints, squad composition, and architectural frameworks tailored to your business objectives.
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Controls Configurator (Left 7 Cols) */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7 space-y-8 bg-[#0e1018]/90 backdrop-blur-xl p-6 sm:p-8 rounded-3xl border border-white/10"
          >
            {/* 1. Platform Target */}
            <div className="space-y-3">
              <label className="text-xs font-mono-tech uppercase tracking-widest text-slate-300 block">
                1. Target Platform & Surface
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { id: 'ai', label: 'AI & Agents' },
                  { id: 'mobile', label: 'Mobile Flagship' },
                  { id: 'web', label: 'Web Platform' },
                  { id: 'enterprise', label: 'Enterprise Suite' }
                ].map((item) => (
                  <button
                    key={item.id}
                    id={`est-platform-${item.id}`}
                    onClick={() => setPlatform(item.id as any)}
                    className={`py-3 px-3 rounded-xl text-xs font-mono-tech uppercase tracking-wider text-center border transition-all cursor-pointer ${
                      platform === item.id
                        ? 'bg-cyan-500/15 border-cyan-400 text-cyan-300 font-semibold shadow-lg'
                        : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Product Maturity & Scope */}
            <div className="space-y-3">
              <label className="text-xs font-mono-tech uppercase tracking-widest text-slate-300 block">
                2. Scope & Maturity Tier
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'mvp', label: 'Validated MVP', desc: 'Core features, rapid deployment' },
                  { id: 'growth', label: 'Scale Flagship', desc: 'Full custom UX, heavy traffic' },
                  { id: 'enterprise', label: 'Enterprise Core', desc: 'SOC2/HIPAA, multi-tenant' }
                ].map((item) => (
                  <button
                    key={item.id}
                    id={`est-scope-${item.id}`}
                    onClick={() => setScope(item.id as any)}
                    className={`p-3.5 rounded-xl text-left border transition-all cursor-pointer ${
                      scope === item.id
                        ? 'bg-indigo-500/15 border-indigo-400 text-indigo-200 shadow-lg'
                        : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs font-mono-tech uppercase tracking-wider font-semibold text-white mb-1">
                      {item.label}
                    </div>
                    <div className="text-[11px] text-slate-400 leading-tight">
                      {item.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 3. AI & Automation Depth */}
            <div className="space-y-3">
              <label className="text-xs font-mono-tech uppercase tracking-widest text-slate-300 block">
                3. Artificial Intelligence Integration
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                {[
                  { id: 'none', label: 'No AI Modules', desc: 'Traditional business logic' },
                  { id: 'rag', label: 'LLM & Vector RAG', desc: 'Embeddings, tool calling' },
                  { id: 'edge-agents', label: 'Edge / Multimodal', desc: 'On-device vision, autonomous agents' }
                ].map((item) => (
                  <button
                    key={item.id}
                    id={`est-ai-${item.id}`}
                    onClick={() => setAiTier(item.id as any)}
                    className={`p-3.5 rounded-xl text-left border transition-all cursor-pointer ${
                      aiTier === item.id
                        ? 'bg-sky-500/15 border-sky-400 text-sky-200 shadow-lg'
                        : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs font-mono-tech uppercase tracking-wider font-semibold text-white mb-1">
                      {item.label}
                    </div>
                    <div className="text-[11px] text-slate-400 leading-tight">
                      {item.desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 4. QA Automation & Delivery Velocity */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-3">
                <label className="text-xs font-mono-tech uppercase tracking-widest text-slate-300 block">
                  4. Automated QA Rigor
                </label>
                <div className="space-y-2">
                  {[
                    { id: 'standard', label: 'Core Testing', desc: 'Unit & integration tests' },
                    { id: 'rigorous', label: 'Zero-Defect Suite', desc: 'Appium/Selenium automated device matrix' }
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setQaLevel(item.id as any)}
                      className={`w-full p-3 rounded-xl text-left border transition-all cursor-pointer ${
                        qaLevel === item.id
                          ? 'bg-emerald-500/15 border-emerald-400 text-emerald-200'
                          : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="text-xs font-mono-tech uppercase tracking-wider font-semibold text-white">
                        {item.label}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {item.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-mono-tech uppercase tracking-widest text-slate-300 block">
                  5. Delivery Velocity
                </label>
                <div className="space-y-2">
                  {[
                    { id: 'standard', label: 'Standard Sprints', desc: 'Measured iterative cadences' },
                    { id: 'expedited', label: 'Expedited Launch', desc: 'Expanded concurrent senior pods' }
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setVelocity(item.id as any)}
                      className={`w-full p-3 rounded-xl text-left border transition-all cursor-pointer ${
                        velocity === item.id
                          ? 'bg-purple-500/15 border-purple-400 text-purple-200'
                          : 'bg-white/[0.03] border-white/[0.08] text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="text-xs font-mono-tech uppercase tracking-wider font-semibold text-white">
                        {item.label}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {item.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Blueprint Estimation Summary Card (Right 5 Cols) */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-5 bg-gradient-to-b from-[#11131f]/95 to-[#0b0c14]/95 border border-white/15 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl backdrop-blur-xl sticky top-28"
          >
            <div className="border-b border-white/[0.08] pb-4">
              <span className="text-xs font-mono-tech uppercase tracking-widest text-cyan-400 block mb-1">
                PROJECTED SPRINT CADENCE
              </span>
              <h3 className="text-xl font-display font-bold text-white">
                Engineered Delivery Pod
              </h3>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.08] space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs font-mono-tech">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>EST. TIMELINE</span>
                </div>
                <div className="text-3xl font-display font-black text-white">
                  {estimatedWeeks} <span className="text-sm font-light text-slate-400">Weeks</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  {velocity === 'expedited' ? 'Parallelized agile sprints' : 'Staged milestones'}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.08] space-y-1">
                <div className="flex items-center gap-1.5 text-slate-400 text-xs font-mono-tech">
                  <Users className="w-3.5 h-3.5 text-indigo-400" />
                  <span>DEDICATED SQUAD</span>
                </div>
                <div className="text-3xl font-display font-black text-white">
                  {squadSize} <span className="text-sm font-light text-slate-400">Engineers</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  Senior architects & QA
                </div>
              </div>
            </div>

            {/* Recommended Stack */}
            <div className="space-y-2.5">
              <span className="text-xs font-mono-tech uppercase tracking-widest text-slate-400 block">
                RECOMMENDED ARCHITECTURE
              </span>
              <div className="flex flex-wrap gap-1.5">
                {keyStack.map((tech, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded bg-white/[0.06] border border-white/10 text-xs font-mono-tech text-slate-200"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Inclusions */}
            <div className="space-y-2 border-t border-white/[0.08] pt-4">
              <span className="text-xs font-mono-tech uppercase tracking-widest text-slate-400 block">
                GUARANTEED INCLUSIONS
              </span>
              <ul className="space-y-2 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>100% IP ownership & bilateral NDA pre-signed</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Automated CI/CD test harness & code audit</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Weekly video demos & sprint retrospective syncs</span>
                </li>
              </ul>
            </div>

            {/* Action */}
            <button
              id="estimator-submit-btn"
              onClick={handleBookProposal}
              className="w-full py-4 rounded-full bg-gradient-to-r from-indigo-500 via-sky-500 to-cyan-400 text-white font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 hover:opacity-95 transition-opacity cursor-pointer shadow-lg shadow-indigo-500/25 active:scale-95"
            >
              <span>Request Verified Proposal & NDA</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
