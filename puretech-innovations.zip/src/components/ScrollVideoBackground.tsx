import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';
import { Film, Play, Pause, Volume2, VolumeX } from 'lucide-react';

interface Scene {
  id: string;
  name: string;
  section: string;
  videoUrl: string;
  poster: string;
}

const SCENES: Scene[] = [
  {
    id: 'scene-hero',
    name: '01 // SHOWREEL: WEB & APPS',
    section: 'hero',
    videoUrl: '/videos/hero-bg.mp4',
    poster: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=2000&q=80'
  },
  {
    id: 'scene-work',
    name: '02 // MOBILE & WEB ATELIER',
    section: 'work',
    videoUrl: '/videos/work-bg.mp4',
    poster: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=2000&q=80'
  },
  {
    id: 'scene-capabilities',
    name: '03 // SYSTEMS ARCHITECTURE',
    section: 'capabilities',
    videoUrl: '/videos/capabilities-bg.mp4',
    poster: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=2000&q=80'
  },
  {
    id: 'scene-what-if',
    name: '04 // SPATIAL & AI PROTOTYPES',
    section: 'what-if',
    videoUrl: '/videos/what-if-bg.mp4',
    poster: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=2000&q=80'
  },
  {
    id: 'scene-contact',
    name: '05 // GLOBAL PRODUCTION REEL',
    section: 'contact',
    videoUrl: '/videos/contact-bg.mp4',
    poster: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=2000&q=80'
  }
];

export const ScrollVideoBackground: React.FC = () => {
  const [activeSceneIndex, setActiveSceneIndex] = useState(0);
  const [isVideoPlaying, setIsVideoPlaying] = useState(true);
  const videoRefs = useRef<{ [key: string]: HTMLVideoElement | null }>({});
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const { scrollYProgress } = useScroll();

  // Smooth spring physics for scroll-driven parallax
  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 85,
    damping: 28,
    restDelta: 0.001
  });

  // Scale subtly expands and breathes with scroll
  const videoScale = useTransform(smoothProgress, [0, 0.25, 0.5, 0.75, 1], [1.05, 1.14, 1.08, 1.15, 1.08]);
  // Vertical parallax drift
  const videoY = useTransform(smoothProgress, [0, 1], ['0%', '-6%']);
  
  // High-visibility overlay tuned so video is vividly noticeable while keeping text readable
  const overlayDarkness = useTransform(
    smoothProgress,
    [0, 0.2, 0.45, 0.7, 0.9, 1],
    [0.34, 0.52, 0.58, 0.56, 0.60, 0.64]
  );

  // Monitor scroll to switch background video scenes dynamically
  useEffect(() => {
    const handleScrollSceneDetection = () => {
      const docHeight = document.documentElement.scrollHeight;
      const progress = window.scrollY / (docHeight - window.innerHeight);

      if (progress < 0.18) {
        setActiveSceneIndex(0); // Hero
      } else if (progress < 0.38) {
        setActiveSceneIndex(1); // Work
      } else if (progress < 0.60) {
        setActiveSceneIndex(2); // Capabilities
      } else if (progress < 0.80) {
        setActiveSceneIndex(3); // What If & Estimator
      } else {
        setActiveSceneIndex(4); // Contact, Newsletter & Footer
      }
    };

    window.addEventListener('scroll', handleScrollSceneDetection, { passive: true });
    handleScrollSceneDetection();
    return () => window.removeEventListener('scroll', handleScrollSceneDetection);
  }, []);

  // Guarantee autoplay on mount and when scene switches
  useEffect(() => {
    const activeScene = SCENES[activeSceneIndex];
    const video = videoRefs.current[activeScene.id];
    if (video) {
      if (isVideoPlaying) {
        const playPromise = video.play();
        if (playPromise !== undefined) {
          playPromise.catch(() => {
            // Autoplay policy prevented immediate playback; wait for first interaction
            const handleFirstInteraction = () => {
              video.play().catch(() => {});
              window.removeEventListener('click', handleFirstInteraction);
              window.removeEventListener('touchstart', handleFirstInteraction);
            };
            window.addEventListener('click', handleFirstInteraction, { once: true });
            window.addEventListener('touchstart', handleFirstInteraction, { once: true });
          });
        }
      } else {
        video.pause();
      }
    }
  }, [activeSceneIndex, isVideoPlaying]);

  // Procedural canvas particle backup
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let w = (canvas.width = window.innerWidth);
    let h = (canvas.height = window.innerHeight);

    const onResize = () => {
      if (!canvas) return;
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', onResize);

    const nodes: { x: number; y: number; vx: number; vy: number; r: number; alpha: number }[] = [];
    for (let i = 0; i < 24; i++) {
      nodes.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
        r: Math.random() * 2 + 1,
        alpha: Math.random() * 0.35 + 0.15
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, w, h);

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(56, 189, 248, ${0.06 * (1 - dist / 120)})`;
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.stroke();
          }
        }
      }

      for (const n of nodes) {
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 0) n.x = w;
        if (n.x > w) n.x = 0;
        if (n.y < 0) n.y = h;
        if (n.y > h) n.y = 0;

        ctx.fillStyle = `rgba(125, 211, 252, ${n.alpha})`;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };
    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', onResize);
    };
  }, []);

  const togglePlayback = () => {
    setIsVideoPlaying((prev) => !prev);
  };

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Fallback procedural canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full object-cover z-0 opacity-60"
      />

      {/* Parallax Scaled Background Video Layer Container */}
      <motion.div
        style={{
          scale: videoScale,
          y: videoY
        }}
        className="absolute inset-0 w-full h-full z-0 will-change-transform"
      >
        {SCENES.map((scene, idx) => {
          const isActive = activeSceneIndex === idx;
          return (
            <motion.div
              key={scene.id}
              initial={false}
              animate={{
                opacity: isActive ? 1 : 0,
                scale: isActive ? 1 : 1.04
              }}
              transition={{
                duration: 1.0,
                ease: [0.16, 1, 0.3, 1]
              }}
              className="absolute inset-0 w-full h-full"
            >
              <video
                ref={(el) => (videoRefs.current[scene.id] = el)}
                autoPlay
                loop
                muted
                playsInline
                preload="auto"
                poster={scene.poster}
                className="w-full h-full object-cover filter contrast-[1.08] brightness-[0.98] saturate-[1.2]"
              >
                <source src={scene.videoUrl} type="video/mp4" />
              </video>
            </motion.div>
          );
        })}
      </motion.div>

      {/* Dynamic Scroll-responsive Vignette & Darkness Layer */}
      <motion.div
        style={{ opacity: overlayDarkness }}
        className="absolute inset-0 bg-[#08090d] z-10 pointer-events-none"
      />

      {/* Edge gradient vignettes (Fantasy.co cinematic framing) */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#08090d] via-transparent to-[#08090d]/70 z-10 pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#08090d]/60 via-transparent to-[#08090d]/60 z-10 pointer-events-none" />

      {/* Subtle scanline texture for high-tech agency depth */}
      <div 
        className="absolute inset-0 opacity-[0.02] z-10 pointer-events-none"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, #000, #000 1px, transparent 1px, transparent 2px)',
          backgroundSize: '100% 3px'
        }}
      />

      {/* High-Tech Background Video HUD Indicator (Fantasy.co signature telemetry) */}
      <div className="fixed bottom-6 left-6 z-30 pointer-events-auto hidden md:flex items-center gap-2">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center gap-3 px-3.5 py-1.5 rounded-full bg-black/70 backdrop-blur-xl border border-white/15 text-[10px] font-mono-tech uppercase tracking-wider text-slate-300 shadow-2xl"
        >
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <Film className="w-3 h-3 text-cyan-400" />
            <span className="text-white font-bold">{SCENES[activeSceneIndex].name}</span>
          </div>

          <span className="text-slate-600">|</span>

          {/* Play / Pause Toggle for Background Video */}
          <button
            onClick={togglePlayback}
            className="hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
            title={isVideoPlaying ? 'Pause background video' : 'Play background video'}
          >
            {isVideoPlaying ? (
              <>
                <Pause className="w-2.5 h-2.5 text-cyan-400" />
                <span className="text-cyan-300">LIVE</span>
              </>
            ) : (
              <>
                <Play className="w-2.5 h-2.5 fill-current text-slate-400" />
                <span className="text-slate-400">PAUSED</span>
              </>
            )}
          </button>

          <span className="text-slate-600">|</span>

          {/* Quick Scene Jumper dots */}
          <div className="flex items-center gap-1.5">
            {SCENES.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveSceneIndex(i)}
                className={`w-1.5 h-1.5 rounded-full transition-all cursor-pointer ${
                  activeSceneIndex === i
                    ? 'w-4 bg-cyan-400'
                    : 'bg-white/25 hover:bg-white/60'
                }`}
                aria-label={`Jump to scene ${i + 1}`}
              />
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};
