import React, { useState } from 'react';
import { Quote, ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TESTIMONIALS } from '../data/content';
import { fadeInUp, fadeInScale } from './MotionWrappers';

export const TestimonialsSection: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  const current = TESTIMONIALS[activeIndex];

  return (
    <section className="py-20 sm:py-32 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.12 }
            }
          }}
          className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6"
        >
          <div>
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 text-xs font-mono-tech uppercase tracking-[0.2em] text-cyan-400 mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              EXECUTIVE ENDORSEMENTS
            </motion.div>
            <motion.h2 variants={fadeInUp} className="text-3xl sm:text-5xl lg:text-6xl font-display font-black text-white tracking-tight leading-tight">
              Client perspectives.
            </motion.h2>
          </div>

          <motion.div variants={fadeInScale} className="flex items-center gap-2">
            <button
              id="prev-testimonial-btn"
              onClick={prevTestimonial}
              className="w-12 h-12 rounded-full border border-white/10 hover:border-white/30 bg-white/[0.03] hover:bg-white/[0.08] flex items-center justify-center text-white transition-colors cursor-pointer active:scale-95"
              aria-label="Previous Endorsement"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              id="next-testimonial-btn"
              onClick={nextTestimonial}
              className="w-12 h-12 rounded-full border border-white/10 hover:border-white/30 bg-white/[0.03] hover:bg-white/[0.08] flex items-center justify-center text-white transition-colors cursor-pointer active:scale-95"
              aria-label="Next Endorsement"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </motion.div>
        </motion.div>

        {/* Featured Testimonial Card */}
        <motion.div
          initial={{ opacity: 0, y: 35, scale: 0.98 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative rounded-3xl bg-gradient-to-br from-[#121422]/95 to-[#090a10]/95 border border-white/15 p-8 sm:p-14 shadow-2xl backdrop-blur-xl"
        >
          <Quote className="w-12 h-12 text-cyan-500/20 mb-6" />

          <AnimatePresence mode="wait">
            <motion.div
              key={current.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="space-y-8"
            >
              <blockquote className="text-2xl sm:text-3xl lg:text-4xl font-display font-medium text-white leading-relaxed tracking-tight">
                "{current.quote}"
              </blockquote>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-6 border-t border-white/10">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-cyan-500/15 border border-cyan-400/30 flex items-center justify-center font-display font-black text-cyan-400 text-lg">
                    {current.author.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <div className="font-display font-bold text-lg text-white">
                      {current.author}
                    </div>
                    <div className="text-xs font-mono-tech text-cyan-400">
                      {current.role}, {current.company} · {current.location}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:items-end gap-1.5">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                    <span className="text-xs font-mono-tech text-slate-400 ml-2">VERIFIED PARTNERSHIP</span>
                  </div>
                  {current.metric && (
                    <div className="text-xs font-mono-tech text-emerald-400">
                      Outcome: {current.metric}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Testimonial Quick Selector Tabs */}
          <div className="flex flex-wrap gap-2 pt-8 mt-6 border-t border-white/[0.08]">
            {TESTIMONIALS.map((t, idx) => {
              const isSelected = idx === activeIndex;
              return (
                <button
                  key={t.id}
                  id={`testimonial-tab-${t.id}`}
                  onClick={() => setActiveIndex(idx)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-mono-tech transition-all duration-200 cursor-pointer border ${
                    isSelected
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40 shadow-sm'
                      : 'bg-white/[0.03] text-slate-400 border-white/[0.06] hover:bg-white/[0.08] hover:text-white'
                  }`}
                >
                  {t.author} ({t.location})
                </button>
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
};
