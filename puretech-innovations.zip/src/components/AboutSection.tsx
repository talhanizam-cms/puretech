import React, { useState } from 'react';
import { ShieldCheck, MapPin, Lock, Cpu, Globe, Terminal, LayoutGrid, Award, CheckCircle2, ChevronRight, Users, Eye, Sliders, Scale } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { COMPANY_FACTS, CORE_PILLARS, MANIFESTO_PILLARS } from '../data/content';
import { fadeInUp, fadeInScale, staggerContainer } from './MotionWrappers';

const PILLAR_ICONS: Record<string, React.ReactNode> = {
  Cpu: <Cpu className="w-5 h-5 text-cyan-400" />,
  Globe: <Globe className="w-5 h-5 text-emerald-400" />,
  Terminal: <Terminal className="w-5 h-5 text-indigo-400" />,
  LayoutGrid: <LayoutGrid className="w-5 h-5 text-rose-400" />,
  ShieldCheck: <ShieldCheck className="w-5 h-5 text-purple-400" />
};

const MANIFESTO_ICONS: Record<string, React.ReactNode> = {
  'top-talent': <Users className="w-5 h-5 text-cyan-400" />,
  'verification': <Eye className="w-5 h-5 text-purple-400" />,
  'flexibility': <Sliders className="w-5 h-5 text-emerald-400" />,
  'the-right-balance': <Scale className="w-5 h-5 text-amber-400" />
};

export const AboutSection: React.FC = () => {
  const [activePillarId, setActivePillarId] = useState(CORE_PILLARS[0].id);
  const activePillar = CORE_PILLARS.find(p => p.id === activePillarId) || CORE_PILLARS[0];

  return (
    <section id="about" className="py-20 sm:py-32 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
        {/* Top Grid: The PureTech Principle & Alpharetta HQ Spotlight */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-80px' }}
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: { staggerChildren: 0.12 }
              }
            }}
            className="lg:col-span-7 space-y-6"
          >
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 text-xs font-mono-tech uppercase tracking-[0.2em] text-cyan-400">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              THE PURETECH PRINCIPLE · HOME 2.0
            </motion.div>
            <motion.h2 variants={fadeInUp} className="text-3xl sm:text-5xl lg:text-6xl font-display font-black text-white tracking-tight leading-tight">
              Technology that moves your business forward.
            </motion.h2>
            <motion.p variants={fadeInUp} className="text-base sm:text-lg text-slate-300 font-light leading-relaxed">
              Founded in Alpharetta, Georgia, PureTech Innovations helps businesses turn ambitious ideas into powerful digital products through innovative technology, smart strategy, and seamless user experiences.
            </motion.p>
            <motion.p variants={fadeInUp} className="text-sm sm:text-base text-slate-400 font-light leading-relaxed">
              We bridge innovation and sustainability to optimize processes, eliminate inefficiencies, and create products built for long-term operational success.
            </motion.p>

            {/* Core Values */}
            <motion.div variants={fadeInUp} className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-2">
                <div className="flex items-center gap-2 text-white font-display font-bold text-base">
                  <Lock className="w-4 h-4 text-cyan-400" />
                  <span>100% IP Confidentiality</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed font-light">
                  Every concept, repository, and data pipeline is fortified with enterprise-grade non-disclosure agreements and zero-trust security.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] space-y-2">
                <div className="flex items-center gap-2 text-white font-display font-bold text-base">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>QA at the Core</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed font-light">
                  Continuous multi-device automation (Appium, Selenium, k6) ensures zero-defect reliability across real production environments.
                </p>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Video / Alpharetta HQ Spotlight */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 30 }}
            whileInView={{ opacity: 1, scale: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 relative"
          >
            <div className="rounded-3xl overflow-hidden border border-white/15 bg-[#121420] shadow-2xl relative group">
              <video
                autoPlay
                loop
                muted
                playsInline
                preload="auto"
                className="w-full h-80 sm:h-96 object-cover filter brightness-90 contrast-110"
              >
                <source src="/videos/capabilities-bg.mp4" type="video/mp4" />
              </video>
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b0d14] via-[#0b0d14]/40 to-transparent pointer-events-none" />

              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-black/80 backdrop-blur-md border border-white/15 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono-tech text-cyan-400 uppercase tracking-wider">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" />
                    GLOBAL HEADQUARTERS
                  </span>
                  <span className="flex items-center gap-1 text-[10px] text-emerald-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    ACTIVE NODE
                  </span>
                </div>
                <div className="text-sm font-display font-bold text-white">
                  14800 Hopewell Rd, Alpharetta, GA 30004
                </div>
                <div className="text-[11px] font-mono-tech text-slate-400">
                  Atlanta Technology Corridor · United States
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* ======================================================== */}
        {/* CORE PILLARS (Interactive Fantasy.co Architectural Layout) */}
        {/* ======================================================== */}
        <div className="space-y-10">
          <div className="max-w-3xl">
            <span className="text-xs font-mono-tech uppercase tracking-[0.2em] text-cyan-400 block mb-2">
              FOUNDATIONAL PILLARS
            </span>
            <h3 className="text-2xl sm:text-4xl lg:text-5xl font-display font-black text-white tracking-tight">
              Built on five pillars of technological excellence.
            </h3>
            <p className="text-slate-300 font-light mt-3 text-sm sm:text-base leading-relaxed">
              How we create digital products designed to solve real-world challenges and unlock doors to sustainable enterprise success.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Pillar Selectors */}
            <div className="lg:col-span-5 space-y-2.5">
              {CORE_PILLARS.map((pillar, idx) => {
                const isSelected = pillar.id === activePillarId;
                return (
                  <button
                    key={pillar.id}
                    id={`pillar-select-${pillar.id}`}
                    onClick={() => setActivePillarId(pillar.id)}
                    className={`w-full text-left p-4 sm:p-5 rounded-2xl transition-all duration-200 cursor-pointer flex items-center justify-between border ${
                      isSelected
                        ? 'bg-white/[0.1] border-cyan-400/40 shadow-xl'
                        : 'bg-white/[0.02] border-white/[0.05] hover:bg-white/[0.05] hover:border-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <span className={`font-mono-tech text-xs font-bold ${
                        isSelected ? 'text-cyan-400' : 'text-slate-400'
                      }`}>
                        0{idx + 1}
                      </span>
                      <span className={`font-display text-sm sm:text-base font-bold ${
                        isSelected ? 'text-white' : 'text-slate-300'
                      }`}>
                        {pillar.title}
                      </span>
                    </div>

                    <div className="shrink-0 ml-2">
                      {PILLAR_ICONS[pillar.iconName]}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Right Pillar In-Depth Display */}
            <div className="lg:col-span-7 bg-[#0e1018]/95 border border-white/10 rounded-2xl sm:rounded-3xl p-6 sm:p-10 relative overflow-hidden backdrop-blur-xl shadow-2xl">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activePillar.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
                    <span className="text-xs font-mono-tech uppercase tracking-widest text-cyan-400">
                      PILLAR EXPLORATION
                    </span>
                    <div className="p-2 rounded-xl bg-white/[0.05] border border-white/10">
                      {PILLAR_ICONS[activePillar.iconName]}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
                      {activePillar.title}
                    </h4>
                    <p className="text-base font-medium text-cyan-300 mt-2">
                      {activePillar.tagline}
                    </p>
                  </div>

                  <p className="text-sm sm:text-base text-slate-300 font-light leading-relaxed">
                    {activePillar.description}
                  </p>

                  <div className="pt-4 border-t border-white/[0.06] flex items-center gap-2 text-xs font-mono-tech text-slate-400">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                    <span>PureTech Quality Standard Guaranteed</span>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* ======================================================== */}
        {/* DEVELOPMENT PRACTICES MANIFESTO (Four Key Tenets) */}
        {/* ======================================================== */}
        <div className="space-y-10">
          <div className="max-w-3xl">
            <span className="text-xs font-mono-tech uppercase tracking-[0.2em] text-cyan-400 block mb-2">
              DEVELOPMENT PRACTICES MANIFESTO
            </span>
            <h3 className="text-2xl sm:text-4xl lg:text-5xl font-display font-black text-white tracking-tight">
              How we engineer software without compromise.
            </h3>
            <p className="text-slate-300 font-light mt-3 text-sm sm:text-base leading-relaxed">
              Our systematic approach eliminates guesswork, fortifies code quality, and ensures seamless execution from kickoff to multi-region production.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {MANIFESTO_PILLARS.map((manifesto) => (
              <motion.div
                key={manifesto.id}
                variants={fadeInScale}
                className="p-6 sm:p-8 rounded-3xl bg-[#0e1017]/90 border border-white/10 space-y-5 hover:border-white/20 transition-all duration-300 backdrop-blur-md"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono-tech text-xs text-cyan-400 font-bold tracking-widest uppercase">
                    TENET {manifesto.number}
                  </span>
                  <div className="p-2.5 rounded-xl bg-white/[0.05] border border-white/10">
                    {MANIFESTO_ICONS[manifesto.id]}
                  </div>
                </div>

                <div>
                  <h4 className="text-xl sm:text-2xl font-display font-bold text-white">
                    {manifesto.title}
                  </h4>
                  <span className="text-xs sm:text-sm font-mono-tech text-slate-400 block mt-1">
                    {manifesto.subtitle}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 font-light leading-relaxed">
                  {manifesto.description}
                </p>

                <div className="space-y-2 pt-2 border-t border-white/[0.06]">
                  <span className="text-[10px] font-mono-tech text-slate-400 uppercase tracking-wider block">
                    KEY PRACTICES
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {manifesto.keyPractices.map((practice, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-1 rounded-lg bg-white/[0.04] border border-white/[0.08] text-[11px] font-mono-tech text-slate-300"
                      >
                        {practice}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Global Delivery Hubs & Clocks */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
          variants={{
            hidden: { opacity: 0, y: 30 },
            visible: {
              opacity: 1,
              y: 0,
              transition: { staggerChildren: 0.1 }
            }
          }}
          className="p-6 sm:p-8 rounded-3xl bg-[#0e1017]/95 border border-white/10 backdrop-blur-md"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-white/10 gap-4">
            <div>
              <span className="text-xs font-mono-tech uppercase tracking-widest text-cyan-400 block mb-1">
                ENGINEERING NODES
              </span>
              <h3 className="text-xl sm:text-2xl font-display font-bold text-white">
                Follow-the-Sun Delivery Velocity
              </h3>
            </div>
            <div className="text-xs text-slate-400 font-mono-tech flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>ALL PODS ACTIVE & CONNECTED</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
            {COMPANY_FACTS.deliveryHubs.map((hub, idx) => (
              <motion.div
                key={idx}
                variants={fadeInScale}
                className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.04] space-y-1"
              >
                <div className="text-xs font-mono-tech text-slate-400 uppercase">
                  {hub.label}
                </div>
                <div className="text-lg font-display font-bold text-white">
                  {hub.city}
                </div>
                <div className="text-xs font-mono-tech text-cyan-400 pt-1">
                  Active Client Sprints
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

