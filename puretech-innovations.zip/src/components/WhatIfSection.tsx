import React, { useState } from 'react';
import { Sparkles, ArrowUpRight, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { WHAT_IF_CONCEPTS } from '../data/content';
import { WhatIfConcept } from '../types';
import { fadeInUp, fadeInScale } from './MotionWrappers';

interface WhatIfProps {
  onPartnerOnConcept: (conceptTitle: string) => void;
}

export const WhatIfSection: React.FC<WhatIfProps> = ({ onPartnerOnConcept }) => {
  const [activeConcept, setActiveConcept] = useState<WhatIfConcept>(WHAT_IF_CONCEPTS[0]);

  // High-tech lab looping video previews
  const conceptVideos: { [key: string]: string } = {
    'concept-1': '/videos/what-if-bg.mp4',
    'concept-2': '/videos/hero-bg.mp4',
    'concept-3': '/videos/capabilities-bg.mp4'
  };

  return (
    <section id="what-if" className="py-24 sm:py-36 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-purple-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-cyan-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Header - Staggered layout */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: { staggerChildren: 0.12 }
            }
          }}
          className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6"
        >
          <div className="max-w-3xl">
            <motion.div variants={fadeInUp} className="inline-flex items-center gap-2 text-xs font-mono-tech uppercase tracking-[0.2em] text-cyan-400 mb-3">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              PURETECH R&D LABS // VISIONARY CONCEPTS
            </motion.div>
            <motion.h2 variants={fadeInUp} className="text-4xl sm:text-6xl lg:text-7xl font-display font-black text-white tracking-tighter leading-none">
              What if?
            </motion.h2>
            <motion.p variants={fadeInUp} className="mt-4 text-base sm:text-xl text-slate-300 font-light leading-relaxed">
              We don’t wait for tech standards to be defined. In our Alpharetta R&D labs, we prototype solutions to tomorrow’s hardest software and human experience challenges.
            </motion.p>
          </div>

          <motion.div
            variants={fadeInScale}
            className="flex items-center gap-2 bg-white/[0.04] p-1.5 rounded-full border border-white/10 self-start md:self-auto overflow-x-auto max-w-full"
          >
            {WHAT_IF_CONCEPTS.map((concept, idx) => (
              <button
                key={concept.id}
                id={`what-if-tab-${concept.id}`}
                onClick={() => setActiveConcept(concept)}
                className={`px-4 sm:px-5 py-2 rounded-full text-xs font-mono-tech uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                  activeConcept.id === concept.id
                    ? 'bg-white text-slate-950 font-bold shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Concept 0{idx + 1}
              </button>
            ))}
          </motion.div>
        </motion.div>

        {/* Big Concept Spotlight Card with Looping Background Video */}
        <motion.div
          initial={{ opacity: 0, y: 35, scale: 0.97 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="rounded-3xl border border-white/15 bg-gradient-to-b from-[#0f111a]/95 to-[#08090e]/95 backdrop-blur-xl overflow-hidden shadow-2xl"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left Info Column */}
            <div className="lg:col-span-7 p-6 sm:p-10 lg:p-12 flex flex-col justify-between space-y-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeConcept.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="flex items-center gap-3">
                    <span className="px-3.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-mono-tech uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                      {activeConcept.tag}
                    </span>
                    <span className="text-xs font-mono-tech text-slate-400">
                      {activeConcept.category}
                    </span>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-2xl sm:text-3xl lg:text-4xl font-display font-black text-white tracking-tight leading-tight">
                      {activeConcept.question}
                    </h3>
                    <div className="text-sm sm:text-base font-mono-tech text-cyan-300">
                      → Proposed Prototype: {activeConcept.solutionTitle}
                    </div>
                  </div>

                  <div className="space-y-4 pt-2">
                    <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/[0.06] space-y-1.5">
                      <span className="text-xs font-mono-tech text-slate-400 uppercase tracking-wider block">
                        ARCHITECTURAL HYPOTHESIS
                      </span>
                      <p className="text-sm sm:text-base text-slate-200 font-light leading-relaxed">
                        {activeConcept.hypothesis}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06] space-y-1">
                        <span className="text-xs font-mono-tech text-emerald-400 uppercase tracking-wider block">
                          TECHNICAL FEASIBILITY
                        </span>
                        <p className="text-xs sm:text-sm text-slate-300 font-light">
                          {activeConcept.technicalFeasibility}
                        </p>
                      </div>

                      <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/[0.06] space-y-1">
                        <span className="text-xs font-mono-tech text-indigo-400 uppercase tracking-wider block">
                          PROJECTED ENTERPRISE VALUE
                        </span>
                        <p className="text-xs sm:text-sm text-slate-300 font-light">
                          {activeConcept.impactPotential}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Bottom Action */}
              <div className="pt-6 border-t border-white/[0.08] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <span className="text-xs font-mono-tech text-slate-400">
                  PURETECH INNOVATION LAB // ALPHA-09 RESEARCH
                </span>

                <button
                  id="what-if-partner-btn"
                  onClick={() => onPartnerOnConcept(activeConcept.solutionTitle)}
                  className="px-7 py-3.5 rounded-full bg-white text-slate-950 font-display font-bold text-xs uppercase tracking-wider hover:bg-slate-200 transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl active:scale-95"
                >
                  <span>Build This Concept</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Right Visual Prototype Column with Active Video Background */}
            <div className="lg:col-span-5 relative min-h-[360px] lg:min-h-full bg-black overflow-hidden border-t lg:border-t-0 lg:border-l border-white/10 flex items-center justify-center">
              {/* Looping video of futuristic concept */}
              {conceptVideos[activeConcept.id] && (
                <video
                  key={activeConcept.id}
                  autoPlay
                  loop
                  muted
                  playsInline
                  poster={activeConcept.prototypeMockup}
                  className="absolute inset-0 w-full h-full object-cover filter brightness-85"
                >
                  <source src={conceptVideos[activeConcept.id]} type="video/mp4" />
                </video>
              )}

              {/* Fallback image */}
              <img
                src={activeConcept.prototypeMockup}
                alt={activeConcept.solutionTitle}
                className="absolute inset-0 w-full h-full object-cover filter brightness-70 -z-10"
              />

              {/* Cinematic Vignette */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 pointer-events-none" />

              {/* Lab Telemetry HUD */}
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-black/80 backdrop-blur-md border border-white/15 text-xs font-mono-tech space-y-1 pointer-events-none">
                <div className="flex items-center justify-between text-cyan-400">
                  <span className="flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 animate-pulse" />
                    LIVE R&D SIMULATION
                  </span>
                  <span>FPS: 120 // HARDWARE: RTX-A6000</span>
                </div>
                <div className="text-white font-display font-bold text-sm">
                  {activeConcept.solutionTitle}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
